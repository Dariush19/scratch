from fastapi import FastAPI
from transformers import pipeline
from pydantic import BaseModel

app = FastAPI(title="Assessment",
              description='''Use a simple LLM to classify text.''',
              version="0.1.0")

# Initialize the zero-shot classification pipeline
classifier = pipeline("zero-shot-classification", model="morit/english_xlm_xnli")

# Define request body schema
class TextRequest(BaseModel):
    text: str

# Define the FastAPI endpoint
@app.post("/analyze")
async def analyze_text(text_request: TextRequest):
    # Perform inference
    result = inference_pipeline(text_request.text)
    return {"result": result}

# Function to perform inference
def inference_pipeline(text):
    sequence_to_classify = text
    candidate_labels = ["aggressive", "sexual", "self-harm", "harassment"]
    hypothesis_template = "This example is {}"
    output = classifier(sequence_to_classify, candidate_labels, hypothesis_template=hypothesis_template)
    return output
