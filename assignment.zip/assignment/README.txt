
Please see below for a report of how I went with the exercises. 

===========================================================================================================================
Folders:

+ assessment
    - compose.yml: Docker compose creating images for both the api and the app.
    + api: 
        - faten.py: Implementation of the step 1 as an API
        - Dockerfile: docker file used to create the image for the api
        - requirements.txt: Python packages required by the build
    + app: 
        - streamFast.py: Implementation of the step 2 as a back-end that calls the api
        - Dockerfile: docker file used to create the image for the app
        - requirements.txt: Python packages required by the build
    + design:
        - Architecture_Context.pdf
            Provides a high level context for the proposed solution. The solution design takes the general framework fromthis document.
        - High Level Solution Design.pdf

===========================================================================================================================
Step 1
The choice of morit/english_xlm_xnli:

These factors were considered:
- Classifying text into specific labels
- The text is English
- Must based on zero-shot.

I spent fair bit of time looking at several models. I tested few of them. Some had a binary classification of Positive or Negative. 
I was surprised that I didn't find that many models on HummingFaces hub that were able to classify unethical language.
In the end, I had to settle on this model, but during the testing I was not very impressed with the accuracy.

to run the api: "uvicorn fasten:app --reload"
to test: "curl -X POST -H "Content-Type: application/json" -d '{"text": "I am feeling very harassed by these comments."}' http://localhost:8080/analyze"
Expected result: 
abels":["harassment","aggressive","self-harm","sexual"],"scores":[0.528403639793396,0.22140784561634064,0.14176678657531738,0.1084217056632042]}}
Also see testing_artifacts/running_api_direct_or_in_container.JPG

===========================================================================================================================
Step 2
This was relatively straight forward. 
I turned the code in previous step to an API and used StreamLit to interface with it.

To test: The api should be running first.
        "streamlit run streamFast.py"
Expected result:
        User interface should be displayed returning results
        Please see testing_artifacts/step2
============================================================================================================================
Step 3
Creating the docker images was straight forward. Please see Dockerfile(s) in the api and app folders.
I tried using:
    - a single docker exposing two different ports for the api and the app. 
    - separate containers for the api but used 'docker build ..'
    - a single compose.yml file that implements two containers for the api and the app.
        - Building the images: From the 'assessment' folder'
            docker-compose up --build
        - output:
            Please see testing_artifacts/docker-compose.txt
    Testing: 
        - The api running in its own container can be tested same as in step 1. The deployed app responds ok.
        - The app running in its own container responds ok and the user interface is displayed. See testing_artifacts/docker-compose.txt
        - Running the streaFast calling the api running in container: ui_calling_api_running_in_container.JPG
============================================================================================================================
Step 4
    - I  created a cluster on OpenShift which in turn created its nodes on my AWS account. 
    - I went through quite few admin tasks to set up groups, roles, authentications, project, and the cli.
    - I pushed images to dockerhub, installed the OpenShift extension and deployed to my project.
    - Sometimes the push to OpenShift worked all the way to deployment of the app but other times it went as far as pushing into the image stream only.
        In this case, I deployed from the console or 'oc new-app'.
    - Please refer to OpenShift.doc for evidence of objects created there.
    - On querying the pods, I can see that the streamlit app running with no error but the api container crashes.
            The logs indicated the error that it can't write to the .cache. (Please see event log in the same openshift.doc.)
    - This error is documented on a couple of place including HummingFace Hub. 
        They recommend setting the HF env variable to the cache location. 
            ENV SENTENCE_TRANSFORMERS_HOME /api/cache/.cache
            ENV HF_HOME /api/cache/.cache
      I have tried both but unfortunatelt none of them helped. 
      I have spent many hours on trouble shooting this but I run out of time.

============================================================================================================================
Ste 5:
    - Architecture_Context.pdf
    - High Level Solution Design.pdf