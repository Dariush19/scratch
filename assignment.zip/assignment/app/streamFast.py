import streamlit as st
import requests


# Define the Streamlit app
def main():
    st.title("Classifying Unethical Language")

    url = "http://localhost:8080/analyze"

    # Text input box
    text_input = st.text_input("Please enter your text:")

    # Button to trigger inference
    if st.button("Analyze"):
        if text_input:
            # Perform inference
            payload = {
                        "text": text_input
            }
            try:
                result = requests.post(url, json=payload, timeout=8000, verify=False)
                st.write("Generated Response:", result.json())
            except requests.exceptions.ConnectionError as e:
                st.write("Error occurred connecting to the API: ", str(e))

        else:
            st.warning("Please enter some text!")


if __name__ == "__main__":
    main()

#
#  streamlit run streamFast.py